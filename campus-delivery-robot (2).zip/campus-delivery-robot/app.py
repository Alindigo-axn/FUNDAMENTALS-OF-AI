"""Streamlit UI for the Mini Campus Delivery Robot.

Run:  streamlit run app.py
"""

from __future__ import annotations

import random

import altair as alt
import pandas as pd
import streamlit as st

from robot import ALERT, NO_ALERT, CampusMap, MDPParams, SensorModel, plan_mission
from robot.mdp import ACTIONS, BLOCKED, CLEAR, MOVE, REROUTE, WAIT
from robot.simulate import evaluate, make_policies, run_episode

# Categorical slots 1-3 of the validated reference palette (pass all-pairs CVD checks).
ACTION_COLORS = {MOVE: "#2a78d6", WAIT: "#eb6834", REROUTE: "#1baf7a"}
ROUTE, DETOUR, UNCERTAIN = "#2a78d6", "#1baf7a", "#eb6834"

st.set_page_config(page_title="Campus Delivery Robot", layout="wide")

st.markdown(
    """
<style>
.grid {display:grid; gap:4px; width:min(100%, 430px);}
.cell {aspect-ratio:1; border-radius:8px; display:flex; flex-direction:column; align-items:center;
       justify-content:center; font:600 13px/1.15 system-ui, sans-serif; color:#0b0b0b;
       background:#f2f1ee; border:2px solid transparent; text-align:center; padding:2px;}
.cell small {font-weight:400; font-size:10px; color:#52514e;}
.wall {background:#3a3936; color:#f0efec;} .wall small {color:#c3c2b7;}
.route {background:#d6e6f8; border-color:#2a78d6;}
.detour {background:#d3f0e5; border-color:#1baf7a; border-style:dashed;}
.unc {background:#fbe1d6; border-color:#eb6834;}
.endpoint {background:#0b0b0b; color:#fcfcfb;} .endpoint small {color:#c3c2b7;}
.legend span {display:inline-block; margin-right:14px; font-size:13px; color:#52514e;}
.legend i {display:inline-block; width:12px; height:12px; border-radius:3px; margin-right:5px; vertical-align:-1px;}
.decision {border-radius:10px; padding:14px 18px; color:#fff; font:600 22px system-ui;}
</style>""",
    unsafe_allow_html=True,
)


def render_grid(campus: CampusMap, route, detour, explored, posterior: float, show_explored: bool) -> str:
    route, detour, explored = set(route or []), set(detour or []), set(explored or [])
    wall_name = {cell: name for name, cells in campus.walls.items() for cell in cells}
    html = [f'<div class="grid" style="grid-template-columns:repeat({campus.cols},1fr)">']
    for r in range(campus.rows):
        for c in range(campus.cols):
            cell = (r, c)
            cls, label, sub = "cell", "", f"({r},{c})"
            if cell == campus.start:
                cls, label, sub = "cell endpoint", "START", campus.start_name
            elif cell == campus.goal:
                cls, label, sub = "cell endpoint", "GOAL", campus.goal_name
            elif cell in wall_name:
                cls, label, sub = "cell wall", "wall", wall_name[cell]
            elif cell == campus.uncertain_cell:
                cls, label, sub = "cell unc", f"? {posterior:.0%}", campus.uncertain_name
            elif cell in route:
                cls, label = "cell route", "route"
            elif cell in detour:
                cls, label = "cell detour", "detour"
            elif show_explored and cell in explored:
                label = "explored"
            html.append(f'<div class="{cls}">{label}<small>{sub}</small></div>')
    html.append("</div>")
    return "".join(html)


# ---------------------------------------------------------------- sidebar ----
if "readings" not in st.session_state:
    st.session_state.readings = [ALERT]

with st.sidebar:
    st.header("Scenario")
    PRESETS = {"One alert -> Wait": [ALERT], "No alert -> Move": [NO_ALERT], "Two alerts -> Reroute": [ALERT, ALERT]}

    def _apply_preset() -> None:
        st.session_state.readings = list(PRESETS[st.session_state.preset])

    st.radio("Quick presets", list(PRESETS), key="preset", on_change=_apply_preset)

    st.subheader("Sensor readings")
    b1, b2, b3 = st.columns(3)
    if b1.button("+ alert", width="stretch"):
        st.session_state.readings.append(ALERT)
    if b2.button("+ clear", width="stretch"):
        st.session_state.readings.append(NO_ALERT)
    if b3.button("Reset", width="stretch"):
        st.session_state.readings = []
    st.caption("Readings so far: " + (", ".join(st.session_state.readings) or "none (prior only)"))

    prior = st.slider("Prior P(passage blocked)", 0.0, 1.0, 0.30, 0.05)
    with st.expander("Sensor model"):
        tp = st.slider("P(alert | Blocked) — sensitivity", 0.5, 1.0, 0.85, 0.01)
        fp = st.slider("P(alert | Clear) — false alarms", 0.0, 0.5, 0.15, 0.01)
    with st.expander("MDP rewards and dynamics"):
        r_clear = st.number_input("Move when Clear", value=10.0, step=1.0)
        r_blocked = st.number_input("Move when Blocked", value=-20.0, step=1.0)
        wait_cost = st.number_input("Wait cost per tick", value=2.0, step=0.5, min_value=0.0)
        step_cost = st.number_input("Cost per extra detour step", value=2.0, step=0.5, min_value=0.0)
        p_cb = st.slider("Wait: Clear -> Blocked", 0.0, 0.5, 0.05, 0.01)
        p_bc = st.slider("Wait: Blocked -> Clear", 0.0, 0.5, 0.10, 0.01)
        gamma = st.slider("Discount gamma", 0.5, 0.99, 0.9, 0.01)
    with st.expander("Map"):
        base = CampusMap()
        free = [(r, c) for r in range(base.rows) for c in range(base.cols)
                if (r, c) not in base.wall_cells and (r, c) not in (base.start, base.goal)]
        unc = st.selectbox("Uncertain passage cell", free, index=free.index(base.uncertain_cell))

sensor = SensorModel(tp, fp)
params = MDPParams(r_clear, r_blocked, wait_cost, step_cost, p_cb, p_bc, gamma)
campus = CampusMap(uncertain_cell=unc)
rep = plan_mission(campus, prior, list(st.session_state.readings), sensor, params)

# ------------------------------------------------------------------ header ---
st.title("Mini Campus Delivery Robot")
st.caption("A* search  →  Bayesian inference  →  Markov decision process · AI Fundamentals final project, QAIRU")

k1, k2, k3, k4 = st.columns(4)
k1.metric("A* route", f"{rep.route.cost} steps",
          help=f"Detour around the passage: +{rep.detour_extra_steps} steps" if rep.passes_uncertain else None)
k2.metric("Nodes expanded (A* vs BFS)", f"{rep.route.nodes_expanded} vs {rep.bfs_route.nodes_expanded}")
k3.metric("P(blocked)", f"{rep.posterior:.3f}", help=f"Prior was {rep.prior:.2f}")
k4.metric("Decision", rep.action)

left, right = st.columns([1, 1.25], gap="large")
with left:
    show_explored = st.toggle("Show cells A* explored", value=False)
    st.markdown(render_grid(campus, rep.route.path, rep.detour.path, [n.cell for n in rep.route.expanded],
                            rep.posterior, show_explored), unsafe_allow_html=True)
    st.markdown(
        f'<div class="legend"><span><i style="background:{ROUTE}"></i>A* route</span>'
        f'<span><i style="background:{DETOUR}"></i>A* detour</span>'
        f'<span><i style="background:{UNCERTAIN}"></i>uncertain passage</span>'
        '<span><i style="background:#3a3936"></i>wall</span></div>',
        unsafe_allow_html=True,
    )
with right:
    st.markdown(f'<div class="decision" style="background:{ACTION_COLORS[rep.action]}">{rep.action}</div>',
                unsafe_allow_html=True)
    st.write(rep.summary())
    for note in rep.notes:
        st.info(note)
    if rep.action == WAIT:
        st.caption("Next step: add a new sensor reading in the sidebar to see what the robot does after waiting.")

# -------------------------------------------------------------------- tabs ---
t1, t2, t3, t4, t5 = st.tabs(["1 · A* search", "2 · Bayes", "3 · MDP", "4 · Live episode", "5 · Evaluation"])

with t1:
    st.markdown("**f(n) = g(n) + h(n)**, h = Manhattan distance (admissible on a 4-connected grid → optimal route).")
    c1, c2 = st.columns([1.3, 1])
    c1.dataframe(pd.DataFrame([{"#": i + 1, "cell": str(n.cell), "g": n.g, "h": n.h, "f": n.f}
                               for i, n in enumerate(rep.route.expanded)]), hide_index=True, width="stretch")
    c2.dataframe(pd.DataFrame([
        {"search": "A* (route)", "cost": rep.route.cost, "nodes expanded": rep.route.nodes_expanded},
        {"search": "BFS (route)", "cost": rep.bfs_route.cost, "nodes expanded": rep.bfs_route.nodes_expanded},
        {"search": "A* (detour)", "cost": rep.detour.cost, "nodes expanded": rep.detour.nodes_expanded},
    ]), hide_index=True, width="stretch")
    c2.write(f"Detour extra steps = **{rep.detour_extra_steps}** → Reroute reward in the MDP = "
             f"**{-params.step_cost * (rep.detour_extra_steps or 0):+.1f}**")

with t2:
    st.markdown("**P(B | z) = P(z | B)·P(B) / [P(z | B)·P(B) + P(z | C)·P(C)]** — the posterior after each reading is the next prior.")
    if rep.bayes_steps:
        st.dataframe(pd.DataFrame([{"#": i + 1, "reading": s.reading, "prior P(B)": round(s.prior, 4),
                                    "P(z|B)": s.likelihood_blocked, "P(z|C)": s.likelihood_clear,
                                    "P(z)": round(s.evidence, 4), "posterior P(B|z)": round(s.posterior, 4)}
                                   for i, s in enumerate(rep.bayes_steps)]), hide_index=True, width="stretch")
        for i, s in enumerate(rep.bayes_steps, 1):
            st.code(f"{i}. {s.explain()}", language=None)
        df = pd.DataFrame({"step": ["prior"] + [f"{i}: {s.reading}" for i, s in enumerate(rep.bayes_steps, 1)],
                           "P(blocked)": [rep.prior] + [s.posterior for s in rep.bayes_steps]})
        df["order"] = range(len(df))
        st.altair_chart(
            alt.Chart(df).mark_line(point=alt.OverlayMarkDef(size=80), strokeWidth=2, color=ROUTE).encode(
                x=alt.X("step:N", sort=alt.SortField("order"), title=None, axis=alt.Axis(labelAngle=0)),
                y=alt.Y("P(blocked):Q", scale=alt.Scale(domain=[0, 1])),
                tooltip=["step", alt.Tooltip("P(blocked):Q", format=".3f")],
            ).properties(height=240, title="Belief that the passage is blocked"),
            width="stretch",
        )
    else:
        st.info("No readings yet — the robot only has the prior. Add readings in the sidebar.")

with t3:
    st.markdown("**(a) World MDP, if the robot could see the passage.** "
                "Value iteration: Q(s,a) = R(s,a) + γ Σ T(s'|s,a) V(s'), V(s) = maxₐ Q(s,a).")
    a1, a2 = st.columns(2)
    a1.dataframe(pd.DataFrame([{"iteration": k, "V(Clear)": round(v[CLEAR], 3), "V(Blocked)": round(v[BLOCKED], 3)}
                               for k, v in enumerate(rep.vi.history)]), hide_index=True, width="stretch")
    a2.dataframe(pd.DataFrame({s: {a: round(rep.vi.q[s][a], 2) for a in ACTIONS} for s in (CLEAR, BLOCKED)}).T,
                 width="stretch")
    a2.write(f"Policy if the state were known: **{rep.vi.policy()}** — waiting never pays off when you can see.")
    st.markdown("**(b) Belief MDP — what the robot actually solves.** The state is b = P(blocked). "
                "Wait costs a tick but brings a new reading (Bayes update), so it has information value.")
    grid = [i / 100 for i in range(101)]
    qdf = pd.DataFrame([{"P(blocked)": b, "action": a, "Q": v}
                        for b in grid for a, v in rep.belief_mdp.q_values(b).items()])
    base_chart = alt.Chart(qdf).mark_line(strokeWidth=2).encode(
        x=alt.X("P(blocked):Q", title="P(blocked)", scale=alt.Scale(domain=[0, 1])),
        y=alt.Y("Q:Q", title="Q(b, action)"),
        color=alt.Color("action:N", scale=alt.Scale(domain=list(ACTION_COLORS), range=list(ACTION_COLORS.values())),
                        legend=alt.Legend(orient="top", title=None)),
        tooltip=["action", alt.Tooltip("P(blocked):Q", format=".2f"), alt.Tooltip("Q:Q", format=".2f")],
    )
    rule = alt.Chart(pd.DataFrame({"x": [rep.posterior]})).mark_rule(strokeDash=[4, 4], color="#52514e").encode(x=alt.X("x:Q", title="P(blocked)"))
    st.altair_chart((base_chart + rule).properties(height=300, title="Value of each action vs belief (dashed = current belief)"),
                    width="stretch")
    st.write("Optimal action by belief: " + " · ".join(f"**{act}** for {lo:.2f}–{hi:.2f}" for lo, hi, act in rep.thresholds))
    st.caption(f"Belief MDP solved on a 21-point grid in {rep.belief_mdp.iterations} value-iteration sweeps.")

with t4:
    st.markdown("Simulate one delivery: the true state is hidden, the sensor is noisy, the robot repeats "
                "**sense → Bayes → decide** until it moves or reroutes.")
    e1, e2, e3 = st.columns(3)
    truth = e1.selectbox("True state of the passage", ["Random (from prior)", "Blocked", "Clear"])
    seed = e2.number_input("Random seed", value=7, step=1)
    e3.write("")
    if e3.button("Run episode", type="primary", width="stretch") or "episode" not in st.session_state:
        pol = make_policies(params, sensor, rep.detour_extra_steps or 0)["AI agent (Bayes + belief MDP)"]
        true_blocked = None if truth.startswith("Random") else truth == "Blocked"
        st.session_state.episode = run_episode(pol, prior, sensor, params, rep.detour_extra_steps or 0,
                                               random.Random(int(seed)), true_blocked=true_blocked)
    ep = st.session_state.episode
    st.dataframe(pd.DataFrame(ep.trace), hide_index=True, width="stretch")
    outcome = "collision!" if ep.collision else "delivered safely"
    st.write(f"Final action **{ep.final_action}** after {ep.waits} wait(s) → total reward **{ep.reward:+.1f}** ({outcome}).")

with t5:
    st.markdown("Monte Carlo comparison on the same random worlds (same seed for every policy).")
    n = st.select_slider("Episodes", [1000, 5000, 10000, 20000], value=10000)
    stats = evaluate(prior=prior, sensor=sensor, params=params,
                     detour_extra_steps=rep.detour_extra_steps or 0, episodes=n)
    sdf = pd.DataFrame([{"policy": s.name, "mean reward": round(s.mean_reward, 2), "± s.e.": round(s.std_error, 2),
                         "collisions": f"{s.collision_rate:.1%}", "reroutes": f"{s.reroute_rate:.1%}",
                         "avg waits": round(s.avg_waits, 2)} for s in stats])
    st.altair_chart(
        alt.Chart(sdf).mark_bar(cornerRadiusEnd=4, color=ROUTE, size=16).encode(
            y=alt.Y("policy:N", sort=None, title=None, axis=alt.Axis(labelLimit=320)),
            x=alt.X("mean reward:Q"),
            tooltip=list(sdf.columns),
        ).properties(height=260, title="Mean reward per episode (higher is better)"),
        width="stretch",
    )
    st.dataframe(sdf, hide_index=True, width="stretch")
