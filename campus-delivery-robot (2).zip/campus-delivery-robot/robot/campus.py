"""The toy campus map shared by all three algorithms.

Assumptions (clearly labelled, as the project guidelines require):
* 5x5 grid, 4-connected moves, every step costs 1.
* Two walls (each a 2-cell wall segment) that are always impassable.
* One "uncertain" cell — a passage that is sometimes blocked by a crowd,
  a cleaning cart, etc. The planner does not know its state for sure.
All numbers are hypothetical; no real dataset is used.

Legend used in the console demo:
    S = start, G = goal, # = wall, ? = uncertain passage, * = route, . = free
"""

from __future__ import annotations

from dataclasses import dataclass, field

from .search import Cell


@dataclass
class CampusMap:
    rows: int = 5
    cols: int = 5
    walls: dict[str, list[Cell]] = field(
        default_factory=lambda: {
            "Construction zone": [(2, 0), (2, 1)],
            "Sports hall": [(1, 3), (1, 4)],
        }
    )
    start: Cell = (4, 0)
    goal: Cell = (0, 4)
    uncertain_cell: Cell = (3, 2)
    start_name: str = "Dormitory"
    goal_name: str = "Library"
    uncertain_name: str = "Atrium passage"

    @property
    def wall_cells(self) -> set[Cell]:
        return {cell for segment in self.walls.values() for cell in segment}

    def validate(self) -> None:
        """Raise ValueError if the map is inconsistent (used by the UI and tests)."""
        for name, cell in (("start", self.start), ("goal", self.goal), ("uncertain", self.uncertain_cell)):
            r, c = cell
            if not (0 <= r < self.rows and 0 <= c < self.cols):
                raise ValueError(f"{name} cell {cell} is outside the {self.rows}x{self.cols} grid")
            if cell in self.wall_cells:
                raise ValueError(f"{name} cell {cell} is inside a wall")
        if self.start == self.goal:
            raise ValueError("start and goal must be different cells")

    def render(self, route: list[Cell] | None = None, alt_route: list[Cell] | None = None) -> str:
        """ASCII picture of the map (used by the console demo and README)."""
        route_set = set(route or [])
        alt_set = set(alt_route or [])
        lines = []
        for r in range(self.rows):
            row = []
            for c in range(self.cols):
                cell = (r, c)
                if cell == self.start:
                    ch = "S"
                elif cell == self.goal:
                    ch = "G"
                elif cell in self.wall_cells:
                    ch = "#"
                elif cell == self.uncertain_cell:
                    ch = "?"
                elif cell in route_set:
                    ch = "*"
                elif cell in alt_set:
                    ch = "o"
                else:
                    ch = "."
                row.append(ch)
            lines.append(" ".join(row))
        return "\n".join(lines)
