"""Algorithm 2 — Bayesian inference: is the passage blocked?

Hidden variable  X in {Blocked, Clear}
Observation      Z in {alert, no_alert}  (from a noisy proximity sensor)

Bayes' rule:
    P(B | z) = P(z | B) * P(B) / P(z)
    P(z)     = P(z | B) * P(B) + P(z | C) * P(C)      (law of total probability)

Several readings are combined by applying the rule repeatedly: the posterior
after reading k becomes the prior for reading k+1 (readings are assumed
conditionally independent given X).
"""

from __future__ import annotations

from dataclasses import dataclass

ALERT = "alert"
NO_ALERT = "no_alert"
VALID_READINGS = (ALERT, NO_ALERT)


@dataclass(frozen=True)
class SensorModel:
    """Likelihoods of the noisy sensor (hypothetical values, see README)."""

    p_alert_given_blocked: float = 0.85  # true-positive rate (sensitivity)
    p_alert_given_clear: float = 0.15  # false-positive rate

    def __post_init__(self) -> None:
        for name in ("p_alert_given_blocked", "p_alert_given_clear"):
            value = getattr(self, name)
            if not 0.0 <= value <= 1.0:
                raise ValueError(f"{name} must be in [0, 1], got {value}")

    def likelihood(self, reading: str, blocked: bool) -> float:
        """P(reading | state)."""
        if reading not in VALID_READINGS:
            raise ValueError(f"unknown reading {reading!r}; use {VALID_READINGS}")
        p_alert = self.p_alert_given_blocked if blocked else self.p_alert_given_clear
        return p_alert if reading == ALERT else 1.0 - p_alert


@dataclass(frozen=True)
class BayesStep:
    """All intermediate numbers of one update — shown in the UI and the demo."""

    reading: str
    prior: float  # P(B) before the reading
    likelihood_blocked: float  # P(z | B)
    likelihood_clear: float  # P(z | C)
    evidence: float  # P(z)
    posterior: float  # P(B | z)

    def explain(self) -> str:
        return (
            f"z={self.reading}: P(B|z) = {self.likelihood_blocked:.2f}*{self.prior:.3f} / "
            f"({self.likelihood_blocked:.2f}*{self.prior:.3f} + {self.likelihood_clear:.2f}*{1 - self.prior:.3f})"
            f" = {self.likelihood_blocked * self.prior:.4f} / {self.evidence:.4f} = {self.posterior:.3f}"
        )


def bayes_update(prior_blocked: float, reading: str, sensor: SensorModel) -> BayesStep:
    """One application of Bayes' rule."""
    if not 0.0 <= prior_blocked <= 1.0:
        raise ValueError(f"prior must be in [0, 1], got {prior_blocked}")
    lik_b = sensor.likelihood(reading, blocked=True)
    lik_c = sensor.likelihood(reading, blocked=False)
    evidence = lik_b * prior_blocked + lik_c * (1.0 - prior_blocked)
    if evidence == 0.0:
        raise ValueError("reading has zero probability under the model (P(z) = 0)")
    posterior = lik_b * prior_blocked / evidence
    return BayesStep(reading, prior_blocked, lik_b, lik_c, evidence, posterior)


def sequential_update(prior_blocked: float, readings: list[str], sensor: SensorModel) -> list[BayesStep]:
    """Apply Bayes' rule once per reading; returns every intermediate step."""
    steps: list[BayesStep] = []
    belief = prior_blocked
    for reading in readings:
        step = bayes_update(belief, reading, sensor)
        steps.append(step)
        belief = step.posterior
    return steps
