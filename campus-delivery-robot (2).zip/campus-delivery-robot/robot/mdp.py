"""Algorithm 3 — Markov Decision Process: Move, Wait or Reroute?

Part A — the world model (a textbook 2-state MDP, "if the robot could see the passage")
    States   S = {Clear, Blocked} + terminal Done (value 0)
    Actions  A = {Move, Wait, Reroute}
    * Move    : R(Clear) = +10 (fast delivery), R(Blocked) = -20 (collision / stuck). Episode ends.
    * Wait    : R = -wait_cost. The passage may change: Clear->Blocked 5 %, Blocked->Clear 10 %.
    * Reroute : R = -step_cost * (extra steps of the A* detour)   <- comes from Algorithm 1. Episode ends.

    Value iteration (Bellman optimality update), discount gamma:
        Q_k(s, a)  = R(s, a) + gamma * sum_s' T(s' | s, a) * V_k(s')
        V_{k+1}(s) = max_a Q_k(s, a)

Part B — the robot cannot see the state; it only has the Bayes belief b = P(Blocked).
    We solve the same problem as an MDP over beliefs (see BeliefMDP below), where
    Wait also yields a new sensor reading processed with Bayes' rule (Algorithm 2).
"""

from __future__ import annotations

from dataclasses import dataclass, field

CLEAR, BLOCKED, DONE = "Clear", "Blocked", "Done"
STATES = (CLEAR, BLOCKED, DONE)
MOVE, WAIT, REROUTE = "Move", "Wait", "Reroute"
ACTIONS = (MOVE, WAIT, REROUTE)

Transition = dict[str, dict[str, dict[str, float]]]  # T[s][a][s'] = probability
Reward = dict[str, dict[str, float]]  # R[s][a]


@dataclass(frozen=True)
class MDPParams:
    """All hypothetical rewards and probabilities in one place."""

    reward_move_clear: float = 10.0
    reward_move_blocked: float = -20.0
    wait_cost: float = 2.0
    step_cost: float = 2.0  # cost per extra step of the A* detour
    p_clear_to_blocked: float = 0.05  # while waiting
    p_blocked_to_clear: float = 0.10  # while waiting
    gamma: float = 0.9


@dataclass
class DeliveryMDP:
    transitions: Transition
    rewards: Reward
    gamma: float

    @classmethod
    def build(cls, params: MDPParams, detour_extra_steps: int | None) -> "DeliveryMDP":
        """Build T and R. If A* found no detour (None), rerouting is heavily penalised."""
        reroute_reward = -100.0 if detour_extra_steps is None else -params.step_cost * detour_extra_steps
        a, b = params.p_clear_to_blocked, params.p_blocked_to_clear
        T: Transition = {
            CLEAR: {
                MOVE: {DONE: 1.0},
                WAIT: {CLEAR: 1 - a, BLOCKED: a},
                REROUTE: {DONE: 1.0},
            },
            BLOCKED: {
                MOVE: {DONE: 1.0},
                WAIT: {CLEAR: b, BLOCKED: 1 - b},
                REROUTE: {DONE: 1.0},
            },
            DONE: {act: {DONE: 1.0} for act in ACTIONS},
        }
        R: Reward = {
            CLEAR: {MOVE: params.reward_move_clear, WAIT: -params.wait_cost, REROUTE: reroute_reward},
            BLOCKED: {MOVE: params.reward_move_blocked, WAIT: -params.wait_cost, REROUTE: reroute_reward},
            DONE: {act: 0.0 for act in ACTIONS},
        }
        return cls(T, R, params.gamma)

    # ---- Bellman machinery -------------------------------------------------
    def q_value(self, state: str, action: str, values: dict[str, float]) -> float:
        expected_next = sum(p * values[s2] for s2, p in self.transitions[state][action].items())
        return self.rewards[state][action] + self.gamma * expected_next

    def bellman_update(self, values: dict[str, float]) -> tuple[dict[str, float], dict[str, dict[str, float]]]:
        """One sweep of value iteration. Returns (new V, Q used to compute it)."""
        q = {s: {a: self.q_value(s, a, values) for a in ACTIONS} for s in STATES}
        q[DONE] = {a: 0.0 for a in ACTIONS}
        new_v = {s: max(q[s].values()) for s in STATES}
        return new_v, q


@dataclass
class ValueIterationResult:
    values: dict[str, float]
    q: dict[str, dict[str, float]]
    history: list[dict[str, float]] = field(default_factory=list)  # V_0, V_1, ...

    @property
    def iterations(self) -> int:
        return len(self.history) - 1

    def policy(self) -> dict[str, str]:
        """Optimal action if the state were known exactly."""
        return {s: max(self.q[s], key=self.q[s].get) for s in (CLEAR, BLOCKED)}


def value_iteration(mdp: DeliveryMDP, tol: float = 1e-6, max_iter: int = 1000) -> ValueIterationResult:
    values = {s: 0.0 for s in STATES}
    history = [dict(values)]
    q: dict[str, dict[str, float]] = {}
    for _ in range(max_iter):
        new_values, q = mdp.bellman_update(values)
        history.append(dict(new_values))
        delta = max(abs(new_values[s] - values[s]) for s in STATES)
        values = new_values
        if delta < tol:
            break
    _, q = mdp.bellman_update(values)  # Q consistent with the final V
    return ValueIterationResult(values, q, history)


# ---------------------------------------------------------------------------
# Part B — the robot cannot SEE the state, it only has a Bayes belief.
# ---------------------------------------------------------------------------
@dataclass
class BeliefMDP:
    """MDP whose state is the belief b = P(Blocked), discretised to a grid 0, 1/N, ..., 1.

    This is how the robot decides under a noisy sensor (a POMDP solved as a
    belief-state MDP). Everything is built from the 2-state world model above
    plus the sensor model of Algorithm 2:

    * Move    : expected reward  (1-b) * R(Clear, Move) + b * R(Blocked, Move); episode ends
    * Reroute : R(Reroute) (A* detour cost); episode ends
    * Wait    : -wait_cost, then
                  1. prediction   b- = b * (1 - p_BC) + (1 - b) * p_CB      (world may change)
                  2. new reading  P(alert) = P(alert|B) b- + P(alert|C) (1 - b-)
                  3. Bayes update b' = P(z|B) b- / P(z)                  (Algorithm 2)
                Q(b, Wait) = -wait_cost + gamma * sum_z P(z) * V(b'_z)

    Unlike the 2-state MDP, waiting here has real value: it buys a new
    sensor reading (value of information). V is stored on the grid and
    linearly interpolated in between.
    """

    params: MDPParams
    reroute_reward: float
    p_alert_given_blocked: float
    p_alert_given_clear: float
    grid_size: int = 20
    values: list[float] = field(default_factory=list)
    history: list[list[float]] = field(default_factory=list)

    @classmethod
    def build(cls, params: MDPParams, detour_extra_steps: int | None, sensor, grid_size: int = 20) -> "BeliefMDP":
        reroute = -100.0 if detour_extra_steps is None else -params.step_cost * detour_extra_steps
        return cls(params, reroute, sensor.p_alert_given_blocked, sensor.p_alert_given_clear, grid_size)

    @property
    def grid(self) -> list[float]:
        return [i / self.grid_size for i in range(self.grid_size + 1)]

    def interpolate(self, b: float, values: list[float]) -> float:
        x = min(max(b, 0.0), 1.0) * self.grid_size
        i = min(int(x), self.grid_size - 1)
        w = x - i
        return (1 - w) * values[i] + w * values[i + 1]

    def wait_outcomes(self, b: float) -> list[tuple[str, float, float]]:
        """[(reading, P(reading), next belief)] after one Wait tick."""
        p = self.params
        b_pred = b * (1 - p.p_blocked_to_clear) + (1 - b) * p.p_clear_to_blocked
        out = []
        for reading, lik_b, lik_c in (
            ("alert", self.p_alert_given_blocked, self.p_alert_given_clear),
            ("no_alert", 1 - self.p_alert_given_blocked, 1 - self.p_alert_given_clear),
        ):
            pz = lik_b * b_pred + lik_c * (1 - b_pred)
            if pz > 0:
                out.append((reading, pz, lik_b * b_pred / pz))
        return out

    def q_values(self, b: float, values: list[float] | None = None) -> dict[str, float]:
        values = self.values if values is None else values
        p = self.params
        q_move = (1 - b) * p.reward_move_clear + b * p.reward_move_blocked
        q_wait = -p.wait_cost + p.gamma * sum(pz * self.interpolate(b2, values) for _, pz, b2 in self.wait_outcomes(b))
        return {MOVE: q_move, WAIT: q_wait, REROUTE: self.reroute_reward}

    def solve(self, tol: float = 1e-6, max_iter: int = 1000) -> "BeliefMDP":
        values = [0.0] * (self.grid_size + 1)
        self.history = [list(values)]
        for _ in range(max_iter):
            new = [max(self.q_values(b, values).values()) for b in self.grid]
            self.history.append(new)
            delta = max(abs(x - y) for x, y in zip(new, values))
            values = new
            if delta < tol:
                break
        self.values = values
        return self

    @property
    def iterations(self) -> int:
        return len(self.history) - 1

    def decide(self, b: float) -> tuple[str, dict[str, float]]:
        if not self.values:
            self.solve()
        scores = self.q_values(b)
        best = max(ACTIONS, key=lambda a: scores[a])  # ties -> order in ACTIONS
        return best, scores

    def thresholds(self, resolution: int = 1000) -> list[tuple[float, float, str]]:
        """Belief intervals where each action is optimal (for the UI and the defense)."""
        intervals: list[tuple[float, float, str]] = []
        current, start = None, 0.0
        for i in range(resolution + 1):
            b = i / resolution
            action, _ = self.decide(b)
            if action != current:
                if current is not None:
                    intervals.append((start, (i - 1) / resolution, current))
                current, start = action, b
        intervals.append((start, 1.0, current))  # type: ignore[arg-type]
        return intervals


def qmdp_decide(q: dict[str, dict[str, float]], p_blocked: float) -> tuple[str, dict[str, float]]:
    """QMDP shortcut: Q(b,a) = (1-b) Q(Clear,a) + b Q(Blocked,a).

    Kept only as a comparison baseline: it assumes the state becomes known after
    one step, so it misjudges the value of waiting (see README, Results).
    """
    scores = {a: (1 - p_blocked) * q[CLEAR][a] + p_blocked * q[BLOCKED][a] for a in ACTIONS}
    return max(ACTIONS, key=lambda a: scores[a]), scores
