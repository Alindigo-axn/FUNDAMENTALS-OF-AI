"""Algorithm 1 — Informed search (A*) on a grid map.

The campus is a small grid. Each move to a 4-neighbour cell costs 1.
A* expands nodes in order of f(n) = g(n) + h(n), where
    g(n) = cost of the best known path from start to n
    h(n) = Manhattan distance from n to the goal (admissible + consistent
           on a 4-connected grid with unit costs, so A* returns an optimal path).

BFS is included only as a baseline: it is also optimal for unit costs, but it
does not use a heuristic, so it usually expands more nodes. Comparing the two
is part of our "Testing and Results" section.
"""

from __future__ import annotations

import heapq
from collections import deque
from dataclasses import dataclass, field
from typing import Iterable

Cell = tuple[int, int]  # (row, col)


@dataclass
class ExpandedNode:
    """One row of the A* trace: which node was taken from the open list."""

    cell: Cell
    g: int
    h: int

    @property
    def f(self) -> int:
        return self.g + self.h


@dataclass
class SearchResult:
    """Output of a search: path (or None), its cost and search statistics."""

    path: list[Cell] | None
    expanded: list[ExpandedNode] = field(default_factory=list)
    algorithm: str = "A*"

    @property
    def found(self) -> bool:
        return self.path is not None

    @property
    def cost(self) -> int | None:
        return None if self.path is None else len(self.path) - 1

    @property
    def nodes_expanded(self) -> int:
        return len(self.expanded)


def manhattan(a: Cell, b: Cell) -> int:
    """Heuristic h(n): |dr| + |dc|. Never overestimates on a 4-connected grid."""
    return abs(a[0] - b[0]) + abs(a[1] - b[1])


def neighbors(cell: Cell, rows: int, cols: int, blocked: set[Cell]) -> Iterable[Cell]:
    """4-connected neighbours in a fixed order (Up, Right, Down, Left) for reproducibility."""
    r, c = cell
    for dr, dc in ((-1, 0), (0, 1), (1, 0), (0, -1)):
        nr, nc = r + dr, c + dc
        if 0 <= nr < rows and 0 <= nc < cols and (nr, nc) not in blocked:
            yield (nr, nc)


def _reconstruct(came_from: dict[Cell, Cell | None], goal: Cell) -> list[Cell]:
    path = [goal]
    while came_from[path[-1]] is not None:
        path.append(came_from[path[-1]])  # type: ignore[arg-type]
    return path[::-1]


def astar(rows: int, cols: int, blocked: set[Cell], start: Cell, goal: Cell) -> SearchResult:
    """A* graph search with Manhattan heuristic.

    Ties on f are broken by smaller h, then by insertion order, so the result
    is deterministic (important for a reproducible demo and tests).
    """
    if start in blocked or goal in blocked:
        return SearchResult(path=None, algorithm="A*")

    counter = 0
    h0 = manhattan(start, goal)
    open_heap: list[tuple[int, int, int, Cell]] = [(h0, h0, counter, start)]
    g_score: dict[Cell, int] = {start: 0}
    came_from: dict[Cell, Cell | None] = {start: None}
    closed: set[Cell] = set()
    expanded: list[ExpandedNode] = []

    while open_heap:
        _f, h, _, current = heapq.heappop(open_heap)
        if current in closed:
            continue  # stale heap entry
        closed.add(current)
        expanded.append(ExpandedNode(current, g_score[current], h))

        if current == goal:
            return SearchResult(_reconstruct(came_from, goal), expanded, "A*")

        for nb in neighbors(current, rows, cols, blocked):
            tentative_g = g_score[current] + 1
            if nb not in g_score or tentative_g < g_score[nb]:
                g_score[nb] = tentative_g
                came_from[nb] = current
                counter += 1
                h_nb = manhattan(nb, goal)
                heapq.heappush(open_heap, (tentative_g + h_nb, h_nb, counter, nb))

    return SearchResult(path=None, expanded=expanded, algorithm="A*")


def bfs(rows: int, cols: int, blocked: set[Cell], start: Cell, goal: Cell) -> SearchResult:
    """Breadth-first search baseline (uninformed, optimal for unit step costs)."""
    if start in blocked or goal in blocked:
        return SearchResult(path=None, algorithm="BFS")

    frontier = deque([start])
    came_from: dict[Cell, Cell | None] = {start: None}
    depth: dict[Cell, int] = {start: 0}
    expanded: list[ExpandedNode] = []

    while frontier:
        current = frontier.popleft()
        expanded.append(ExpandedNode(current, depth[current], 0))
        if current == goal:
            return SearchResult(_reconstruct(came_from, goal), expanded, "BFS")
        for nb in neighbors(current, rows, cols, blocked):
            if nb not in came_from:
                came_from[nb] = current
                depth[nb] = depth[current] + 1
                frontier.append(nb)

    return SearchResult(path=None, expanded=expanded, algorithm="BFS")
