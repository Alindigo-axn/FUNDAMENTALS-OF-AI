"""How the three algorithms work together for ONE delivery decision.

    1. A*      plans the shortest route Dormitory -> Library on the known map.
    2. A*      plans a detour that avoids the uncertain passage;
               detour length - route length = extra steps  ---> Reroute cost in the MDP
    3. Bayes   turns the sensor readings into P(passage blocked)  ---> belief for the MDP
    4. MDP     (a) 2-state world MDP, value iteration -> what to do if the state were known
               (b) belief MDP (state = P(blocked)), value iteration -> Move / Wait / Reroute
    5. Output  the route the robot will actually follow + a human-readable explanation
"""

from __future__ import annotations

from dataclasses import dataclass, field

from .bayes import BayesStep, SensorModel, sequential_update
from .campus import CampusMap
from .mdp import (
    MOVE,
    REROUTE,
    WAIT,
    BeliefMDP,
    DeliveryMDP,
    MDPParams,
    ValueIterationResult,
    value_iteration,
)
from .search import Cell, SearchResult, astar, bfs


@dataclass
class MissionReport:
    campus: CampusMap
    route: SearchResult  # A* on the known map
    bfs_route: SearchResult  # baseline for comparison
    detour: SearchResult  # A* with the uncertain cell treated as a wall
    passes_uncertain: bool
    detour_extra_steps: int | None
    prior: float
    bayes_steps: list[BayesStep]
    posterior: float
    mdp: DeliveryMDP  # 2-state world model
    vi: ValueIterationResult  # its value iteration
    belief_mdp: BeliefMDP  # the decision model actually used
    action: str
    action_scores: dict[str, float]
    thresholds: list[tuple[float, float, str]]
    final_route: list[Cell] | None
    notes: list[str] = field(default_factory=list)

    def summary(self) -> str:
        """One-paragraph explanation used by the CLI and the UI."""
        if not self.route.found:
            return "No route exists from start to goal on this map."
        if not self.passes_uncertain:
            return (
                f"The optimal route ({self.route.cost} steps) does not use the {self.campus.uncertain_name}, "
                "so no decision under uncertainty is needed: the robot simply drives."
            )
        detour_txt = (
            f"+{self.detour_extra_steps} steps" if self.detour_extra_steps is not None else "no detour exists"
        )
        what = {
            MOVE: "drive through the passage now",
            WAIT: "wait one tick in front of the passage and scan again",
            REROUTE: "take the detour found by A*",
        }[self.action]
        return (
            f"A* route: {self.route.cost} steps through the {self.campus.uncertain_name} (detour: {detour_txt}). "
            f"After {len(self.bayes_steps)} sensor reading(s) P(blocked) = {self.posterior:.3f}. "
            f"MDP decision: {self.action} -> the robot will {what}."
        )


def plan_mission(
    campus: CampusMap,
    prior_blocked: float,
    readings: list[str],
    sensor: SensorModel | None = None,
    params: MDPParams | None = None,
) -> MissionReport:
    sensor = sensor or SensorModel()
    params = params or MDPParams()
    campus.validate()
    walls = campus.wall_cells

    # 1) A* on the known map (the uncertain cell is assumed passable).
    route = astar(campus.rows, campus.cols, walls, campus.start, campus.goal)
    bfs_route = bfs(campus.rows, campus.cols, walls, campus.start, campus.goal)

    # 2) A* detour that avoids the uncertain cell -> cost of the Reroute action.
    detour = astar(campus.rows, campus.cols, walls | {campus.uncertain_cell}, campus.start, campus.goal)
    passes_uncertain = bool(route.path and campus.uncertain_cell in route.path)
    if passes_uncertain:
        detour_extra = None if not detour.found else detour.cost - route.cost  # type: ignore[operator]
    else:
        detour_extra = 0

    # 3) Bayes: belief that the passage is blocked.
    steps = sequential_update(prior_blocked, readings, sensor)
    posterior = steps[-1].posterior if steps else prior_blocked

    # 4) MDP: (a) 2-state world model, (b) belief MDP that makes the decision.
    mdp = DeliveryMDP.build(params, detour_extra)
    vi = value_iteration(mdp)
    belief_mdp = BeliefMDP.build(params, detour_extra, sensor).solve()
    notes: list[str] = []
    if not route.found:
        action, scores, final_route = REROUTE, {}, None
        notes.append("Goal unreachable even with the passage open.")
    elif not passes_uncertain:
        _, scores = belief_mdp.decide(posterior)
        action, final_route = MOVE, route.path
        notes.append("Route avoids the uncertain passage; MDP decision not needed.")
    else:
        action, scores = belief_mdp.decide(posterior)
        final_route = detour.path if action == REROUTE else route.path
        if action == REROUTE and not detour.found:
            final_route = None
            notes.append("Reroute chosen but no detour exists; the robot must wait for the passage.")
    if not readings:
        notes.append("No sensor readings: the decision uses the prior only.")

    return MissionReport(
        campus=campus,
        route=route,
        bfs_route=bfs_route,
        detour=detour,
        passes_uncertain=passes_uncertain,
        detour_extra_steps=detour_extra,
        prior=prior_blocked,
        bayes_steps=steps,
        posterior=posterior,
        mdp=mdp,
        vi=vi,
        belief_mdp=belief_mdp,
        action=action,
        action_scores=scores,
        thresholds=belief_mdp.thresholds(),
        final_route=final_route,
        notes=notes,
    )
