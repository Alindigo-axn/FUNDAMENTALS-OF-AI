"""Monte Carlo evaluation: does the Bayes + MDP agent actually do better?

One episode = the robot arrives in front of the uncertain passage.
    * The true state is sampled from the prior (hidden from the robot).
    * Every tick: the sensor produces a noisy reading -> Bayes update -> policy picks an action.
    * Wait:    reward -wait_cost, the true state may change (MDP transition model),
               the belief is propagated with the same model (prediction step).
    * Move:    +10 if the passage is really clear, -20 if it is really blocked (collision). Episode ends.
    * Reroute: -step_cost * detour_extra_steps. Episode ends.
    * After max_ticks waits the robot is forced to reroute (prevents infinite waiting).

The rewards are the same ones the MDP was built with, so the comparison is fair.
"""

from __future__ import annotations

import random
from dataclasses import dataclass
from typing import Callable

from .bayes import ALERT, NO_ALERT, SensorModel, bayes_update
from .mdp import BLOCKED, CLEAR, MOVE, REROUTE, BeliefMDP, DeliveryMDP, MDPParams, qmdp_decide, value_iteration

Policy = Callable[[float], str]  # belief P(Blocked) -> action


@dataclass
class EpisodeResult:
    reward: float
    final_action: str
    waits: int
    collision: bool
    trace: list[dict]


@dataclass
class PolicyStats:
    name: str
    mean_reward: float
    std_error: float
    collision_rate: float
    reroute_rate: float
    avg_waits: float
    episodes: int


def make_policies(params: MDPParams, sensor: SensorModel, detour_extra_steps: int) -> dict[str, Policy]:
    belief_mdp = BeliefMDP.build(params, detour_extra_steps, sensor).solve()
    q_world = value_iteration(DeliveryMDP.build(params, detour_extra_steps)).q
    return {
        "AI agent (Bayes + belief MDP)": lambda b: belief_mdp.decide(b)[0],
        "Bayes + QMDP shortcut": lambda b: qmdp_decide(q_world, b)[0],
        "Bayes + fixed rule (Move if P<0.5)": lambda b: MOVE if b < 0.5 else REROUTE,
        "Always Move": lambda b: MOVE,
        "Always Reroute": lambda b: REROUTE,
    }


def run_episode(
    policy: Policy,
    prior: float,
    sensor: SensorModel,
    params: MDPParams,
    detour_extra_steps: int,
    rng: random.Random,
    max_ticks: int = 10,
    true_blocked: bool | None = None,
) -> EpisodeResult:
    blocked = rng.random() < prior if true_blocked is None else true_blocked
    belief, total, waits, trace = prior, 0.0, 0, []
    reroute_reward = -params.step_cost * detour_extra_steps

    for tick in range(max_ticks + 1):
        p_alert = sensor.p_alert_given_blocked if blocked else sensor.p_alert_given_clear
        reading = ALERT if rng.random() < p_alert else NO_ALERT
        belief = bayes_update(belief, reading, sensor).posterior
        action = policy(belief) if tick < max_ticks else REROUTE
        trace.append(
            {"tick": tick, "true_state": BLOCKED if blocked else CLEAR, "reading": reading,
             "belief": round(belief, 4), "action": action}
        )
        if action == MOVE:
            r = params.reward_move_blocked if blocked else params.reward_move_clear
            return EpisodeResult(total + r, MOVE, waits, blocked, trace)
        if action == REROUTE:
            return EpisodeResult(total + reroute_reward, REROUTE, waits, False, trace)
        # WAIT: pay the cost, the world evolves, belief is predicted forward.
        total -= params.wait_cost
        waits += 1
        if blocked:
            blocked = rng.random() >= params.p_blocked_to_clear
        else:
            blocked = rng.random() < params.p_clear_to_blocked
        belief = belief * (1 - params.p_blocked_to_clear) + (1 - belief) * params.p_clear_to_blocked
    raise RuntimeError("unreachable: the last tick always reroutes")


def evaluate(
    prior: float = 0.3,
    sensor: SensorModel | None = None,
    params: MDPParams | None = None,
    detour_extra_steps: int = 2,
    episodes: int = 10_000,
    seed: int = 42,
) -> list[PolicyStats]:
    sensor = sensor or SensorModel()
    params = params or MDPParams()
    results = []
    for name, policy in make_policies(params, sensor, detour_extra_steps).items():
        rng = random.Random(seed)  # same random worlds for every policy
        eps = [run_episode(policy, prior, sensor, params, detour_extra_steps, rng) for _ in range(episodes)]
        rewards = [e.reward for e in eps]
        mean = sum(rewards) / episodes
        var = sum((r - mean) ** 2 for r in rewards) / (episodes - 1)
        results.append(
            PolicyStats(
                name=name,
                mean_reward=mean,
                std_error=(var / episodes) ** 0.5,
                collision_rate=sum(e.collision for e in eps) / episodes,
                reroute_rate=sum(e.final_action == REROUTE for e in eps) / episodes,
                avg_waits=sum(e.waits for e in eps) / episodes,
                episodes=episodes,
            )
        )
    return results
