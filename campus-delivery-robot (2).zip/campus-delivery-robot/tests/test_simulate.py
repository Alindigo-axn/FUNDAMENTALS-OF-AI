import random

import pytest

from robot.bayes import SensorModel
from robot.mdp import MDPParams, REROUTE
from robot.simulate import evaluate, make_policies, run_episode


@pytest.mark.parametrize("prior", [0.1, 0.3, 0.5, 0.7])
def test_ai_agent_is_best_or_tied(prior):
    stats = {s.name: s for s in evaluate(prior=prior, episodes=5000, seed=7)}
    ai = stats.pop("AI agent (Bayes + belief MDP)")
    for other in stats.values():
        # allow statistical noise of two standard errors
        assert ai.mean_reward >= other.mean_reward - 2 * (ai.std_error + other.std_error), other.name


def test_ai_agent_beats_naive_policies_clearly():
    stats = {s.name: s for s in evaluate(prior=0.3, episodes=5000, seed=1)}
    ai = stats["AI agent (Bayes + belief MDP)"].mean_reward
    assert ai > stats["Always Move"].mean_reward + 1.0
    assert ai > stats["Always Reroute"].mean_reward + 1.0


def test_episode_always_terminates_and_forced_reroute():
    policies = make_policies(MDPParams(), SensorModel(), 2)
    always_wait = lambda b: "Wait"
    ep = run_episode(always_wait, 0.3, SensorModel(), MDPParams(), 2, random.Random(0), max_ticks=5)
    assert ep.final_action == REROUTE and ep.waits == 5
    assert len(policies) == 5


def test_evaluation_is_reproducible():
    a = evaluate(episodes=500, seed=3)
    b = evaluate(episodes=500, seed=3)
    assert [s.mean_reward for s in a] == [s.mean_reward for s in b]
