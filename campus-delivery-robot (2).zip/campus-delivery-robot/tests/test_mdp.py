import pytest

from robot.bayes import SensorModel
from robot.mdp import (
    BLOCKED, CLEAR, MOVE, REROUTE, WAIT, BeliefMDP, DeliveryMDP, MDPParams, qmdp_decide, value_iteration,
)

P = MDPParams()  # +10 / -20 / wait -2 / step cost 2 / gamma 0.9


@pytest.fixture(scope="module")
def vi():
    return value_iteration(DeliveryMDP.build(P, detour_extra_steps=2))


@pytest.fixture(scope="module")
def belief_mdp():
    return BeliefMDP.build(P, 2, SensorModel()).solve()


def test_first_bellman_update_by_hand(vi):
    # From V0 = 0: V1(Clear) = max(10, -2, -4) = 10, V1(Blocked) = max(-20, -2, -4) = -2
    assert vi.history[1][CLEAR] == pytest.approx(10.0)
    assert vi.history[1][BLOCKED] == pytest.approx(-2.0)


def test_value_iteration_converges_to_bellman_fixed_point(vi):
    mdp = DeliveryMDP.build(P, 2)
    new_v, _ = mdp.bellman_update(vi.values)
    for s in vi.values:
        assert new_v[s] == pytest.approx(vi.values[s], abs=1e-5)
    assert vi.values[CLEAR] == pytest.approx(10.0)
    assert vi.values[BLOCKED] == pytest.approx(-4.0, abs=1e-4)


def test_q_wait_clear_by_hand(vi):
    # Q(C, Wait) = -2 + 0.9 * (0.95 * 10 + 0.05 * (-4)) = 6.37
    assert vi.q[CLEAR][WAIT] == pytest.approx(6.37, abs=1e-3)


def test_known_state_policy(vi):
    assert vi.policy() == {CLEAR: MOVE, BLOCKED: REROUTE}


def test_wait_probabilities_sum_to_one(belief_mdp):
    for b in (0.0, 0.3, 0.7, 1.0):
        assert sum(pz for _, pz, _ in belief_mdp.wait_outcomes(b)) == pytest.approx(1.0)


@pytest.mark.parametrize("belief,expected", [(0.0703, MOVE), (0.7083, WAIT), (0.9323, REROUTE)])
def test_belief_mdp_decisions(belief_mdp, belief, expected):
    assert belief_mdp.decide(belief)[0] == expected


def test_thresholds_are_ordered_move_wait_reroute(belief_mdp):
    actions = [a for _, _, a in belief_mdp.thresholds()]
    assert actions == [MOVE, WAIT, REROUTE]


def test_no_detour_means_never_reroute():
    m = BeliefMDP.build(P, None, SensorModel()).solve()
    assert all(a != REROUTE for _, _, a in m.thresholds())


def test_expensive_detour_shrinks_reroute_region():
    cheap = BeliefMDP.build(P, 1, SensorModel()).solve().thresholds()
    pricey = BeliefMDP.build(P, 6, SensorModel()).solve().thresholds()
    start_of_reroute = lambda th: next((lo for lo, _, a in th if a == REROUTE), 1.01)
    assert start_of_reroute(pricey) > start_of_reroute(cheap)


def test_qmdp_baseline_runs(vi):
    action, scores = qmdp_decide(vi.q, 0.5)
    assert action in scores and set(scores) == {MOVE, WAIT, REROUTE}
