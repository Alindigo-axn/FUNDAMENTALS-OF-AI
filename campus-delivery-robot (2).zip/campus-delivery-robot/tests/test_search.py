import random

import pytest

from robot.campus import CampusMap
from robot.search import astar, bfs, manhattan


def random_grid(seed: int, size: int = 6, wall_ratio: float = 0.25):
    rng = random.Random(seed)
    cells = [(r, c) for r in range(size) for c in range(size)]
    start, goal = rng.sample(cells, 2)
    walls = {cell for cell in cells if rng.random() < wall_ratio} - {start, goal}
    return size, walls, start, goal


def is_valid_path(path, walls, size, start, goal):
    if path[0] != start or path[-1] != goal:
        return False
    for a, b in zip(path, path[1:]):
        if manhattan(a, b) != 1 or b in walls or not (0 <= b[0] < size and 0 <= b[1] < size):
            return False
    return True


def test_default_campus_route():
    c = CampusMap()
    res = astar(c.rows, c.cols, c.wall_cells, c.start, c.goal)
    assert res.cost == 8  # Manhattan distance, walls do not lengthen it
    assert c.uncertain_cell in res.path
    assert is_valid_path(res.path, c.wall_cells, c.rows, c.start, c.goal)


def test_detour_is_two_steps_longer():
    c = CampusMap()
    res = astar(c.rows, c.cols, c.wall_cells | {c.uncertain_cell}, c.start, c.goal)
    assert res.cost == 10
    assert c.uncertain_cell not in res.path


def test_astar_expands_fewer_nodes_than_bfs_on_campus():
    c = CampusMap()
    a = astar(c.rows, c.cols, c.wall_cells, c.start, c.goal)
    b = bfs(c.rows, c.cols, c.wall_cells, c.start, c.goal)
    assert a.cost == b.cost
    assert a.nodes_expanded == 9 and b.nodes_expanded == 20


@pytest.mark.parametrize("seed", range(300))
def test_astar_is_optimal_and_never_expands_more_than_bfs(seed):
    size, walls, start, goal = random_grid(seed)
    a = astar(size, size, walls, start, goal)
    b = bfs(size, size, walls, start, goal)
    assert a.found == b.found
    if a.found:
        assert a.cost == b.cost  # BFS is optimal for unit costs -> A* must match
        assert is_valid_path(a.path, walls, size, start, goal)
        assert a.nodes_expanded <= b.nodes_expanded


@pytest.mark.parametrize("seed", range(50))
def test_manhattan_heuristic_is_admissible(seed):
    size, walls, _, goal = random_grid(seed)
    for r in range(size):
        for c in range(size):
            if (r, c) in walls:
                continue
            true = bfs(size, size, walls, (r, c), goal)
            if true.found:
                assert manhattan((r, c), goal) <= true.cost


def test_unreachable_goal_returns_none():
    walls = {(0, 1), (1, 0), (1, 1)}  # start (0,0) is boxed in
    res = astar(3, 3, walls, (0, 0), (2, 2))
    assert res.path is None and res.cost is None


def test_start_inside_wall_returns_none():
    assert astar(3, 3, {(0, 0)}, (0, 0), (2, 2)).path is None


def test_start_equals_goal():
    res = astar(3, 3, set(), (1, 1), (1, 1))
    assert res.path == [(1, 1)] and res.cost == 0
