import pytest

from robot.bayes import ALERT, NO_ALERT, SensorModel, bayes_update, sequential_update

S = SensorModel()  # P(alert|B)=0.85, P(alert|C)=0.15


def test_single_alert_matches_hand_calculation():
    step = bayes_update(0.3, ALERT, S)
    # 0.85*0.3 / (0.85*0.3 + 0.15*0.7) = 0.255 / 0.36
    assert step.evidence == pytest.approx(0.36)
    assert step.posterior == pytest.approx(0.255 / 0.36)
    assert round(step.posterior, 3) == 0.708


def test_no_alert_lowers_belief():
    step = bayes_update(0.3, NO_ALERT, S)
    assert step.posterior == pytest.approx(0.045 / 0.64)  # 0.0703
    assert step.posterior < 0.3


def test_two_alerts():
    steps = sequential_update(0.3, [ALERT, ALERT], S)
    assert [round(s.posterior, 4) for s in steps] == [0.7083, 0.9323]
    assert steps[1].prior == pytest.approx(steps[0].posterior)  # posterior becomes the new prior


def test_order_of_readings_does_not_matter():
    a = sequential_update(0.3, [ALERT, NO_ALERT, ALERT], S)[-1].posterior
    b = sequential_update(0.3, [NO_ALERT, ALERT, ALERT], S)[-1].posterior
    assert a == pytest.approx(b)


def test_alert_then_no_alert_returns_to_prior_for_symmetric_sensor():
    # 0.85/0.15 and 0.15/0.85 likelihood ratios cancel out
    assert sequential_update(0.3, [ALERT, NO_ALERT], S)[-1].posterior == pytest.approx(0.3)


def test_useless_sensor_does_not_change_belief():
    useless = SensorModel(0.5, 0.5)
    assert bayes_update(0.3, ALERT, useless).posterior == pytest.approx(0.3)


@pytest.mark.parametrize("prior", [0.0, 1.0])
def test_certain_prior_is_not_changed(prior):
    assert bayes_update(prior, ALERT, S).posterior == pytest.approx(prior)


def test_posteriors_of_both_states_sum_to_one():
    step = bayes_update(0.42, ALERT, S)
    p_clear = step.likelihood_clear * (1 - step.prior) / step.evidence
    assert step.posterior + p_clear == pytest.approx(1.0)


def test_invalid_inputs_raise():
    with pytest.raises(ValueError):
        bayes_update(1.5, ALERT, S)
    with pytest.raises(ValueError):
        bayes_update(0.3, "beep", S)
    with pytest.raises(ValueError):
        SensorModel(1.2, 0.1)


def test_empty_readings():
    assert sequential_update(0.3, [], S) == []
