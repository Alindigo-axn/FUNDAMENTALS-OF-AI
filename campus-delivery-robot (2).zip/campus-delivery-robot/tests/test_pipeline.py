import pytest

from robot import ALERT, NO_ALERT, CampusMap, plan_mission
from robot.mdp import MOVE, REROUTE, WAIT


@pytest.mark.parametrize(
    "readings,action",
    [([NO_ALERT], MOVE), ([ALERT], WAIT), ([ALERT, ALERT], REROUTE)],
)
def test_three_demo_scenarios(readings, action):
    rep = plan_mission(CampusMap(), 0.3, readings)
    assert rep.action == action
    assert rep.detour_extra_steps == 2


def test_reroute_uses_astar_detour():
    rep = plan_mission(CampusMap(), 0.3, [ALERT, ALERT])
    assert rep.final_route == rep.detour.path
    assert CampusMap().uncertain_cell not in rep.final_route


def test_move_uses_original_route():
    rep = plan_mission(CampusMap(), 0.3, [NO_ALERT])
    assert rep.final_route == rep.route.path


def test_route_that_avoids_uncertain_cell_needs_no_decision():
    campus = CampusMap(uncertain_cell=(4, 4))  # far corner, not on the route
    rep = plan_mission(campus, 0.9, [ALERT, ALERT])
    assert not rep.passes_uncertain
    assert rep.action == MOVE


def test_invalid_map_raises():
    with pytest.raises(ValueError):
        plan_mission(CampusMap(start=(2, 0)), 0.3, [])  # start inside a wall
    with pytest.raises(ValueError):
        plan_mission(CampusMap(goal=(9, 9)), 0.3, [])


def test_summary_mentions_decision():
    rep = plan_mission(CampusMap(), 0.3, [ALERT])
    assert "Wait" in rep.summary() and "0.708" in rep.summary()
