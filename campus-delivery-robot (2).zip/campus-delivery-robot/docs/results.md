# Results — Monte Carlo evaluation (20,000 episodes per cell, seed 42)

Mean reward per episode (higher is better). Bold = best in the row.

### Experiment 1 — different priors P(blocked), detour = +2 steps

| setting | AI agent (Bayes + belief MDP) | Bayes + QMDP shortcut | Bayes + fixed rule (Move if P<0.5) | Always Move | Always Reroute |
|---|---:|---:|---:|---:|---:|
| prior 0.1 | **7.54** | 7.34 | 7.03 | 7.03 | -4.00 |
| prior 0.3 | **3.89** | 3.13 | 3.67 | 1.02 | -4.00 |
| prior 0.5 | **0.76** | -0.28 | **0.76** | -5.03 | -4.00 |
| prior 0.7 | **-1.95** | -3.78 | -2.14 | -10.97 | -4.00 |

### Experiment 2 — different detour lengths found by A*, prior = 0.3

| setting | AI agent (Bayes + belief MDP) | Bayes + QMDP shortcut | Bayes + fixed rule (Move if P<0.5) | Always Move | Always Reroute |
|---|---:|---:|---:|---:|---:|
| detour +1 | **4.38** | 3.91 | **4.38** | 1.02 | -2.00 |
| detour +2 | **3.89** | 3.13 | 3.67 | 1.02 | -4.00 |
| detour +4 | **2.84** | 1.60 | 2.23 | 1.02 | -8.00 |
| detour +6 | **1.51** | 1.16 | 0.80 | 1.02 | -12.00 |

### Experiment 3 — behaviour at the default setting (prior 0.3, detour +2)

| policy | mean reward | ± s.e. | collisions | reroutes | avg waits |
|---|---:|---:|---:|---:|---:|
| AI agent (Bayes + belief MDP) | 3.89 | 0.07 | 8.0% | 21.3% | 0.36 |
| Bayes + QMDP shortcut | 3.13 | 0.07 | 6.2% | 17.4% | 1.29 |
| Bayes + fixed rule (Move if P<0.5) | 3.67 | 0.06 | 4.4% | 35.8% | 0.00 |
| Always Move | 1.02 | 0.10 | 29.9% | 0.0% | 0.00 |
| Always Reroute | -4.00 | 0.00 | 0.0% | 100.0% | 0.00 |
