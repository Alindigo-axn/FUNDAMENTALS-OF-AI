"""Reproduce the tables in docs/results.md:  python experiments.py > docs/results.md"""

from robot.simulate import evaluate

EPISODES, SEED = 20_000, 42


def table(title: str, rows: list[tuple[str, list]]) -> None:
    names = [s.name for s in rows[0][1]]
    print(f"\n### {title}\n")
    print("| setting | " + " | ".join(names) + " |")
    print("|---|" + "---:|" * len(names))
    for label, stats in rows:
        best = max(s.mean_reward for s in stats)
        cells = [f"**{s.mean_reward:.2f}**" if s.mean_reward == best else f"{s.mean_reward:.2f}" for s in stats]
        print(f"| {label} | " + " | ".join(cells) + " |")


if __name__ == "__main__":
    print(f"# Results — Monte Carlo evaluation ({EPISODES:,} episodes per cell, seed {SEED})")
    print("\nMean reward per episode (higher is better). Bold = best in the row.")
    table("Experiment 1 — different priors P(blocked), detour = +2 steps",
          [(f"prior {p}", evaluate(prior=p, episodes=EPISODES, seed=SEED)) for p in (0.1, 0.3, 0.5, 0.7)])
    table("Experiment 2 — different detour lengths found by A*, prior = 0.3",
          [(f"detour +{d}", evaluate(detour_extra_steps=d, episodes=EPISODES, seed=SEED)) for d in (1, 2, 4, 6)])
    stats = evaluate(episodes=EPISODES, seed=SEED)
    print("\n### Experiment 3 — behaviour at the default setting (prior 0.3, detour +2)\n")
    print("| policy | mean reward | ± s.e. | collisions | reroutes | avg waits |")
    print("|---|---:|---:|---:|---:|---:|")
    for s in stats:
        print(f"| {s.name} | {s.mean_reward:.2f} | {s.std_error:.2f} | {s.collision_rate:.1%} | "
              f"{s.reroute_rate:.1%} | {s.avg_waits:.2f} |")
