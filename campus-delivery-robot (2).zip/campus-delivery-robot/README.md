# Mini Campus Delivery Robot

**AI Fundamentals (AIF1303) — Final Project, QAIRU, 2026**
Team: Talgat Alikhan · Aldiyar Meirambek (see [Team contributions](#team-contributions))

A simulated robot delivers a package across a small campus map from the **Dormitory** to the **Library**.
Its shortest route goes through the **Atrium passage**, which is sometimes blocked by a crowd.
The robot has a noisy sensor and must decide: **Move** through, **Wait** and scan again, or **Reroute**.

Three course algorithms solve the problem together, each from a different topic:

| # | Topic (course week) | Algorithm | Job in the project | Output |
|---|---|---|---|---|
| 1 | Search (week 2) | **A\*** with Manhattan heuristic | shortest route + detour that avoids the passage | route, detour length |
| 2 | Probability (week 6) | **Bayesian inference** | P(passage blocked) from noisy sensor readings | posterior probability |
| 3 | Sequential decisions (week 5) | **MDP + value iteration** | Move / Wait / Reroute | action |

## How the three algorithms work together

```
            ┌──────────────┐  detour extra steps   ┌───────────────────────┐
 map ─────▶ │ 1. A* search │ ─────────────────────▶│                       │
            └──────────────┘  (Reroute cost)       │ 3. MDP                │
            ┌──────────────┐  P(blocked)           │    value iteration    │ ──▶ Move / Wait / Reroute
 sensor ──▶ │ 2. Bayes     │ ─────────────────────▶│    over beliefs       │       + final route
            └──────────────┘  (belief)             └───────────────────────┘
                    ▲                                        │
                    └──────── Wait = new sensor reading ─────┘
```

A\* produces the **cost** of the Reroute action, Bayes produces the **belief** the MDP acts on, and the MDP's
Wait action produces a **new reading** that goes back into Bayes. None of the three is decorative:
remove any one and the robot can no longer make the decision.

## Quick start

```bash
pip install -r requirements.txt
streamlit run app.py               # web UI (recommended for the demo)
python demo.py                     # console: three scenarios, every intermediate step printed
python demo.py --readings alert alert --prior 0.3
python demo.py --evaluate          # Monte Carlo policy comparison
python -m pytest -q                # 394 tests
python experiments.py > docs/results.md   # regenerate the results tables
```

Python 3.10+. Core algorithms use only the standard library; Streamlit/Altair/pandas are used by the UI only.

## Project structure

```
robot/
  search.py     Algorithm 1: A* (+ BFS baseline)
  bayes.py      Algorithm 2: Bayes' rule, sensor model, sequential updates
  mdp.py        Algorithm 3: 2-state world MDP + belief MDP, value iteration
  campus.py     the 5x5 map and its assumptions
  pipeline.py   plan_mission(): runs 1 → 2 → 3 and returns every intermediate number
  simulate.py   Monte Carlo episodes and baseline policies
app.py          Streamlit UI
demo.py         console demo (input → steps → output → explanation)
experiments.py  produces docs/results.md
tests/          pytest suite
docs/results.md evaluation tables
```

## Assumptions (all values are hypothetical, no real dataset)

| Item | Value |
|---|---|
| Map | 5×5 grid, 4-connected, every step costs 1 |
| Walls | Construction zone (2,0)-(2,1), Sports hall (1,3)-(1,4) |
| Start / goal | Dormitory (4,0) → Library (0,4) |
| Uncertain cell | Atrium passage (3,2) |
| Prior P(Blocked) | 0.30 |
| Sensor | P(alert \| Blocked) = 0.85, P(alert \| Clear) = 0.15 |
| Rewards | Move: +10 if clear, −20 if blocked · Wait: −2 per tick · Reroute: −2 × extra detour steps |
| Wait dynamics | Clear→Blocked 5 %, Blocked→Clear 10 % per tick |
| Discount γ | 0.9 |

Every value can be changed in the UI sidebar.

---

## Algorithm 1 — A\* search

**Why A\*:** we need the *shortest* route on a map with obstacles. A\* is optimal when the heuristic is admissible,
and it explores fewer cells than uninformed search (BFS) because the heuristic points it towards the goal.

**How it works:** take the open node with the lowest `f(n) = g(n) + h(n)` where `g` = steps from the start and
`h` = Manhattan distance `|Δrow| + |Δcol|` to the goal. Manhattan distance never overestimates on a 4-connected grid
(each step changes the row or the column by exactly 1), so it is **admissible** and also **consistent**, and the first time
the goal is popped its path is optimal.

**Input → steps → output**

```
INPUT : 5x5 grid, start (4,0), goal (0,4), walls {(2,0),(2,1),(1,3),(1,4)}
STEPS : (4,0) g=0 h=8 f=8 → (3,0) g=1 h=7 → (3,1) g=2 h=6 → (3,2) g=3 h=5 → (2,2) → (1,2) → (0,2) → (0,3) → (0,4)
OUTPUT: route (4,0)→(3,0)→(3,1)→(3,2)→(2,2)→(1,2)→(0,2)→(0,3)→(0,4), cost 8
        detour avoiding (3,2): cost 10 → +2 extra steps
        A* expanded 9 nodes, BFS expanded 20 (same cost 8)

. . * * G        * = A* route
. . * # #        o = detour
# # * o .        ? = uncertain passage
* * ? o .        # = wall
S o o o .
```

**One sentence:** A\* finds the optimal 8-step route and an optimal 10-step detour, and the 2-step difference becomes the
price of rerouting in the MDP.

## Algorithm 2 — Bayesian inference

**Why Bayes:** the sensor is noisy (15 % false alarms, misses 15 % of blockages), so a single alert does not mean the passage
is blocked. Bayes' rule combines what we knew before (prior) with how reliable the sensor is (likelihoods).

**How it works:**

```
P(B | z) = P(z | B) · P(B) / P(z),     P(z) = P(z | B) · P(B) + P(z | C) · P(C)
```

With several readings the posterior after reading *k* becomes the prior for reading *k+1*
(readings are assumed conditionally independent given the true state).

**Input → steps → output**

| readings | calculation | P(Blocked) |
|---|---|---|
| — | prior | 0.300 |
| no_alert | 0.15·0.3 / (0.15·0.3 + 0.85·0.7) = 0.045 / 0.640 | **0.070** |
| alert | 0.85·0.3 / (0.85·0.3 + 0.15·0.7) = 0.255 / 0.360 | **0.708** |
| alert, alert | 0.85·0.708 / (0.85·0.708 + 0.15·0.292) | **0.932** |

**One sentence:** one alert raises the belief from 30 % to 71 %, not to 100 %, because the sensor makes mistakes.

## Algorithm 3 — Markov decision process

**Why an MDP:** the decision has a time dimension — waiting costs time but the crowd may leave, and actions have different
rewards depending on the hidden state. An MDP models states, actions, transition probabilities and rewards, and value
iteration finds the best long-term action.

**(a) World MDP — if the robot could see the passage.**
States {Clear, Blocked} (+ terminal Done), actions {Move, Wait, Reroute}. Move and Reroute end the episode; Wait costs −2
and the state may change. Value iteration:

```
Q_k(s,a)   = R(s,a) + γ · Σ_s' T(s'|s,a) · V_k(s')
V_{k+1}(s) = max_a Q_k(s,a)
```

| iteration | V(Clear) | V(Blocked) |
|---|---:|---:|
| 0 | 0 | 0 |
| 1 | 10 | −2 *(max of −20, −2, −4)* |
| 2 | 10 | −2.72 |
| … | … | … |
| 6 (converged) | 10 | −4 |

Converged Q-table: Clear {Move 10, Wait 6.37, Reroute −4}, Blocked {Move −20, Wait −4.34, Reroute −4}.
Check by hand: Q(Clear, Wait) = −2 + 0.9 · (0.95 · 10 + 0.05 · (−4)) = 6.37.
**Policy if the state were known:** Clear → Move, Blocked → Reroute. Waiting is never optimal when you can see.

**(b) Belief MDP — what the robot actually solves.** The robot cannot see the state, it only has `b = P(Blocked)` from
Bayes. So the MDP's state becomes the belief `b`, discretised to 21 points (0, 0.05, …, 1):

* `Q(b, Move) = (1−b)·10 + b·(−20)`
* `Q(b, Reroute) = −2 × (A* extra steps) = −4`
* `Q(b, Wait) = −2 + γ · Σ_z P(z) · V(b'_z)` — after waiting the world may change (prediction with the Wait transition
  table), then a new reading `z` arrives and `b'_z` is computed **with Bayes' rule** (Algorithm 2).

Value iteration on this 21-state MDP converges in 11 sweeps and gives the policy:

| P(Blocked) | 0.00 – 0.28 | 0.28 – 0.79 | 0.79 – 1.00 |
|---|---|---|---|
| best action | **Move** | **Wait** (scan again) | **Reroute** |

**Input → output for the three demo scenarios (prior 0.3):**

| readings | P(Blocked) | Q(Move) | Q(Wait) | Q(Reroute) | decision |
|---|---:|---:|---:|---:|---|
| no_alert | 0.070 | **7.89** | 4.51 | −4.00 | **Move** |
| alert | 0.708 | −11.25 | **−3.28** | −4.00 | **Wait** |
| alert, alert | 0.932 | −17.97 | −4.86 | **−4.00** | **Reroute** |

**One sentence:** Wait only makes sense *because of uncertainty* — it buys one more sensor reading — which is exactly what
the belief MDP captures and the simple world MDP cannot.

---

## Testing and results

### Automated tests (`python -m pytest -q` → 394 passed)

| file | what is checked |
|---|---|
| `test_search.py` | campus route = 8, detour = 10; on **300 random grids** A\* cost = BFS cost, path is valid, A\* never expands more nodes than BFS; Manhattan heuristic ≤ true distance on 50 random grids; unreachable goal / start in wall / start = goal |
| `test_bayes.py` | hand-calculated posteriors (0.708, 0.070, 0.932); order of readings does not matter; useless sensor (0.5/0.5) leaves belief unchanged; certain priors stay certain; invalid inputs raise |
| `test_mdp.py` | first Bellman update by hand; V is a fixed point of the Bellman operator; Q(Clear, Wait) = 6.37 by hand; known-state policy; Wait outcome probabilities sum to 1; thresholds ordered Move→Wait→Reroute; no detour ⇒ never Reroute; longer detour ⇒ smaller Reroute region |
| `test_pipeline.py` | the three scenarios give Move / Wait / Reroute; Reroute follows the A\* detour; route that avoids the passage needs no decision; invalid maps raise |
| `test_simulate.py` | AI agent best or tied for 4 priors; clearly beats naive policies; episodes always terminate; results reproducible with a seed |

### Monte Carlo evaluation (`docs/results.md`, 20,000 episodes per setting)

The true state is hidden and sampled from the prior; the sensor is noisy; the robot repeats *sense → Bayes → decide*.
All policies are scored with the same rewards and the same random seed.

| prior P(Blocked) | **AI agent** (Bayes + belief MDP) | Bayes + QMDP shortcut | Bayes + fixed rule (Move if P<0.5) | Always Move | Always Reroute |
|---|---:|---:|---:|---:|---:|
| 0.1 | **7.54** | 7.34 | 7.03 | 7.03 | −4.00 |
| 0.3 | **3.89** | 3.13 | 3.67 | 1.02 | −4.00 |
| 0.5 | **0.76** | −0.28 | **0.76** | −5.03 | −4.00 |
| 0.7 | **−1.95** | −3.78 | −2.14 | −10.97 | −4.00 |

| detour found by A\* (prior 0.3) | **AI agent** | QMDP | fixed rule | Always Move | Always Reroute |
|---|---:|---:|---:|---:|---:|
| +1 | **4.38** | 3.91 | **4.38** | 1.02 | −2.00 |
| +2 | **3.89** | 3.13 | 3.67 | 1.02 | −4.00 |
| +4 | **2.84** | 1.60 | 2.23 | 1.02 | −8.00 |
| +6 | **1.51** | 1.16 | 0.80 | 1.02 | −12.00 |

**What the results show**

* The full agent is best or tied in every setting. "Always Move" collides 30 % of the time.
* The fixed 0.5 threshold is competitive only when the detour is short. When A\* reports a long detour, the agent
  waits instead of rerouting and the gap grows (2.84 vs 2.23 at +4). This is the A\* → MDP link at work.
* The **QMDP shortcut** (weight the world-MDP Q-values by the belief) is worse than the belief MDP: it assumes the state
  becomes known after one step, so it misjudges the value of waiting. This was our first design. The simulation showed
  the problem, and we replaced it with the belief MDP.
* Trade-off: the agent collides in 8 % of episodes vs 4 % for the fixed rule, because it moves at beliefs up to 0.28.
  If collisions are unacceptable, raising the collision penalty (−20 → −50) shifts the Move threshold down. You can try this
  live in the UI.

## Limitations and possible improvements

* Toy scale: 5×5 grid, one uncertain cell, hand-picked probabilities and rewards. **Next:** several uncertain cells, a bigger
  map, probabilities estimated from logged sensor data.
* Readings are assumed conditionally independent. A real sensor can make correlated mistakes.
* The belief grid (21 points) with linear interpolation approximates the true value function. A finer grid or an exact
  POMDP solver would remove the approximation.
* A\* replans from the start. **Next:** replan from the robot's current cell (D\* Lite) as it moves.
* **Future development (Physical AI track):** run the same pipeline on a real robot (ROS 2 + a lidar/ultrasonic sensor), or
  replace the hand-set sensor model with a trained classifier whose confusion matrix supplies P(alert | state).

## Team contributions

| Member | Responsibilities |
|---|---|
| Talgat Alikhan | A\* + BFS (`search.py`, `campus.py`), Streamlit UI (`app.py`), search tests |
| Aldiyar Meirambek | Bayes (`bayes.py`), MDP + value iteration (`mdp.py`), simulation and experiments, Bayes/MDP tests |
| Both | pipeline integration (`pipeline.py`), README, demo and defense; each member can explain all three algorithms |

## AI use declaration

See [`AI_USE_DECLARATION.md`](AI_USE_DECLARATION.md).

## References

1. Russell S.J., Norvig P. *Artificial Intelligence: A Modern Approach*, 4th ed. — ch. 3 (A\*), ch. 12–13 (Bayes),
   ch. 17 (MDPs, value iteration, POMDPs / belief-state MDPs).
2. QAIRU AI Fundamentals lecture notes and lab guides, weeks 2, 5, 6.
