"""Console demo: input -> key steps -> output -> one-sentence explanation, for each algorithm.

Usage:
    python demo.py                          # three ready-made scenarios
    python demo.py --readings alert alert   # your own sensor readings
    python demo.py --prior 0.5 --readings no_alert
    python demo.py --evaluate               # Monte Carlo comparison of policies
"""

from __future__ import annotations

import argparse

from robot import ALERT, NO_ALERT, CampusMap, MDPParams, SensorModel, plan_mission
from robot.mdp import ACTIONS, BLOCKED, CLEAR
from robot.pipeline import MissionReport
from robot.simulate import evaluate

LINE = "=" * 72


def section(title: str) -> None:
    print(f"\n{LINE}\n{title}\n{LINE}")


def print_report(rep: MissionReport, sensor: SensorModel, params: MDPParams) -> None:
    c = rep.campus

    section("ALGORITHM 1 — A* search (route planning)")
    print(f"INPUT : {c.rows}x{c.cols} grid, start {c.start_name} {c.start}, goal {c.goal_name} {c.goal}")
    print(f"        walls: {c.walls}")
    print(f"        uncertain cell: {c.uncertain_name} {c.uncertain_cell}; heuristic h = Manhattan distance")
    print("STEPS : expansion order (cell, g, h, f):")
    for node in rep.route.expanded:
        print(f"        {node.cell}  g={node.g}  h={node.h}  f={node.f}")
    print(f"OUTPUT: route {rep.route.path}  cost = {rep.route.cost}")
    print(f"        detour avoiding {c.uncertain_cell}: cost = {rep.detour.cost}  (extra steps = {rep.detour_extra_steps})")
    print(f"        A* expanded {rep.route.nodes_expanded} nodes vs BFS {rep.bfs_route.nodes_expanded} (same cost {rep.bfs_route.cost})")
    print("\n" + c.render(rep.route.path, rep.detour.path))
    print("        (* = A* route, o = detour, ? = uncertain passage)")
    print("WHY   : A* is optimal with an admissible heuristic and explores fewer cells than BFS.")

    section("ALGORITHM 2 — Bayesian inference (is the passage blocked?)")
    print(f"INPUT : prior P(Blocked) = {rep.prior:.2f}; sensor P(alert|B) = {sensor.p_alert_given_blocked}, "
          f"P(alert|C) = {sensor.p_alert_given_clear}")
    print(f"        readings: {[s.reading for s in rep.bayes_steps] or 'none'}")
    print("STEPS :")
    for i, step in enumerate(rep.bayes_steps, 1):
        print(f"        {i}. {step.explain()}")
    print(f"OUTPUT: P(Blocked | readings) = {rep.posterior:.3f}")
    print("WHY   : Bayes' rule combines prior knowledge with a noisy sensor instead of trusting it blindly.")

    section("ALGORITHM 3 — MDP (Move / Wait / Reroute)")
    print(f"INPUT : rewards Move: Clear {params.reward_move_clear:+}, Blocked {params.reward_move_blocked:+}; "
          f"Wait {-params.wait_cost:+}; Reroute {-params.step_cost * (rep.detour_extra_steps or 0):+} "
          f"(= -{params.step_cost} x {rep.detour_extra_steps} extra A* steps); gamma = {params.gamma}")
    print(f"        Wait transitions: Clear->Blocked {params.p_clear_to_blocked}, Blocked->Clear {params.p_blocked_to_clear}")
    print("STEPS : (a) 2-state world MDP — value iteration")
    for k, v in enumerate(rep.vi.history[:4]):
        print(f"        V_{k}: Clear={v[CLEAR]:7.3f}  Blocked={v[BLOCKED]:7.3f}")
    print(f"        converged after {rep.vi.iterations} iterations; Q-table:")
    for s in (CLEAR, BLOCKED):
        print("        " + s.ljust(8) + "  ".join(f"{a}={rep.vi.q[s][a]:7.2f}" for a in ACTIONS))
    print(f"        policy if the state were KNOWN: {rep.vi.policy()}")
    print(f"      (b) belief MDP (state = P(Blocked) on a 21-point grid): {rep.belief_mdp.iterations} iterations")
    print("        optimal action by belief: " + ", ".join(f"[{a:.2f}-{b:.2f}] {act}" for a, b, act in rep.thresholds))
    if rep.action_scores:
        print(f"        Q(b={rep.posterior:.3f}, .) = " + ", ".join(f"{a}: {v:.2f}" for a, v in rep.action_scores.items()))
    print(f"OUTPUT: action = {rep.action}")
    print("WHY   : the MDP weighs the reward of each action and the chance the passage clears over time.")

    section("RESULT")
    print(rep.summary())
    print(f"Final route: {rep.final_route}")
    for note in rep.notes:
        print(f"Note: {note}")


def main() -> None:
    parser = argparse.ArgumentParser(description="Mini Campus Delivery Robot — A* + Bayes + MDP")
    parser.add_argument("--prior", type=float, default=0.3, help="prior P(passage blocked), default 0.3")
    parser.add_argument("--readings", nargs="*", choices=[ALERT, NO_ALERT], help="sensor readings in order")
    parser.add_argument("--evaluate", action="store_true", help="run the Monte Carlo policy comparison")
    args = parser.parse_args()

    campus, sensor, params = CampusMap(), SensorModel(), MDPParams()

    if args.evaluate:
        section(f"MONTE CARLO EVALUATION (10,000 episodes, prior={args.prior})")
        print(f"{'policy':38s}{'mean reward':>12s}{'± s.e.':>8s}{'collisions':>12s}{'reroutes':>10s}{'waits':>7s}")
        for s in evaluate(prior=args.prior, sensor=sensor, params=params):
            print(f"{s.name:38s}{s.mean_reward:12.2f}{s.std_error:8.2f}{s.collision_rate:12.1%}"
                  f"{s.reroute_rate:10.1%}{s.avg_waits:7.2f}")
        return

    scenarios = [args.readings] if args.readings is not None else [[NO_ALERT], [ALERT], [ALERT, ALERT]]
    for readings in scenarios:
        print(f"\n\n######## SCENARIO: prior={args.prior}, readings={readings} ########")
        print_report(plan_mission(campus, args.prior, readings, sensor, params), sensor, params)


if __name__ == "__main__":
    main()
